'''
Created by SEK0061@vsb.cz
'''
from KUKALIB.kukaconnector import KUKA_Handler
from KUKALIB import Parameters as Parameters
import threading
import numpy as np
from sensor_connect import FT_CONNECT
import logging
import re
import time

# Setup basic logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initializing global variables
running = threading.Event()
robot = KUKA_Handler(Parameters.ip_KUKACell, Parameters.port_KUKACell)
sensor = FT_CONNECT(net_ft_host=Parameters.ip_sensor)
script_thread = None

reset_position = Parameters.KUKA_reset_rel_move
force_threshold = Parameters.force_threshold    
impedance_factor = Parameters.impedance_factor  # adjust for step movement

def robot_stop_move():
    robot.client.write("MOVE_CONT", '{X ' + str(reset_position[0]) +
                        ', Y ' + str(reset_position[1]) +
                        ', Z ' + str(reset_position[2]) + '}')

def move_robot_wrist():
    # Open the connection to the robot
    robot.KUKA_Open()
    # tare sensor
    sensor.set_tare() 
    
    running.set()
    
    try:
        while running.is_set():
            packet_count = Parameters.packet_group# packets to be averaged for force calculation
            accumulated_fx = accumulated_fy = accumulated_fz = 0.0
            sensor.start_streaming()
            
            for _ in range(packet_count):
                
                success, ft_streaming, sequence = sensor.read_ft_streaming(timeout=1)
                if success:
                    _, _, _, fx, fy, fz = ft_streaming
                    accumulated_fx += fx
                    accumulated_fy += fy
                    accumulated_fz += fz
                else:
                    logger.info("No data Received")
            
            if packet_count > 0:       #
                avg_fx = accumulated_fx / packet_count
                avg_fy = accumulated_fy / packet_count
                avg_fz = accumulated_fz / packet_count
                
            else:
                logger.error("set packet count value greater than zero")
                avg_fx = avg_fy = avg_fz = 0.0

            # Determine if movement is needed based on force threshold
            if avg_fx>force_threshold or avg_fx<(-1*force_threshold):
                x_force = True
            else:
                x_force=False

            if avg_fy>force_threshold or avg_fy<(-1*force_threshold):
                y_force = True
            else:
                y_force=False

            if avg_fz>force_threshold or avg_fz<(-1*force_threshold):
                z_force = True
            else:
                z_force=False
            
            if x_force or y_force or z_force:
                logger.info(f"robot is moving")
                x_move = impedance_factor*avg_fy
                y_move = impedance_factor*avg_fx
                z_move = -1*impedance_factor*avg_fz
                rel_move_distance = np.array([x_move, y_move, z_move, 0.0, 0.0, 0.0], dtype="float")
                robot.client.write("MOVE_CONT", '{X ' + str(rel_move_distance[0]) +
                                    ', Y ' + str(rel_move_distance[1]) +
                                    ', Z ' + str(rel_move_distance[2]) + '}')
            else:
                robot_stop_move()
                logger.info(f"threshold not crossed")
            
            sensor.stop_streaming()

    except KeyboardInterrupt:
        logger.info(f"Stopped by user ")
    finally:
        robot.KUKA_Close()
        sensor.stop_streaming()

def start_script():
    global script_thread
    
    if not running.is_set():
        running.set()  # Signal that we intend to run
        script_thread = threading.Thread(target=move_robot_wrist)
        script_thread.start()

def stop_script():
    logger.info("its stopped")
    global robot
    robot.KUKA_Open()
    running.clear()  # Signal to stop the loop in move_robot_wrist
    
    robot_stop_move()    
    robot.KUKA_Close()
    sensor.stop_streaming()

if __name__ == '__main__':
    move_robot_wrist()
