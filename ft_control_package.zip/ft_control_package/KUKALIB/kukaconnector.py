'''
Utilizes kukavarproxy to create kuka handling commands
'''
import numpy as np
from KUKALIB.kukavarproxy import openshowvar
from KUKALIB import Parameters

# Definition of a class KUKA_Handler
class KUKA_Handler:
    def __init__(self, ipAddress, port):
        self.connected = False
        if is_valid_ipv4(ipAddress):
            self.ipAddress = ipAddress
        self.port = port
        self.client = None

        self.__pos_default = Parameters.KUKA_reset_rel_move
        self.__pos_actual = Parameters.KUKA_reset_rel_move

    def KUKA_Open(self):
        if self.connected == False:
            self.client = openshowvar(self.ipAddress, self.port)
            res = self.client.can_connect

            if res == True:
                print('Connection is established!')
                self.connected = True
                return True
            else:
                print('Connection is broken! Check configuration or restart C3_Server at KUKA side.')
                self.connected = False
                return False
        else:
            print('Connection is ready!')

    
    def KUKA_Close(self):
        if self.connected == True:
            self.client.close()
            self.connected = False
            return True

        else:
            return False

    def KUKA_GetActualPos(self):
        return (self.__pos_actual)
    
    def KUKA_ReadVar(self, var, printRes = False):
        if self.connected == True:
            res = self.client.read(var, debug=False)
            if printRes:
                print(res)
            return (res)

        else:
            return False

# --------------------------------------------------- Helpers

def is_valid_ipv4(ip):
    parts = ip.split(".")
    if len(parts) < 4 or len(parts) > 4:
        return "invalid IP length should be 4 not greater or less than 4"
    else:
        while len(parts) == 4:
            a = int(parts[0])
            b = int(parts[1])
            c = int(parts[2])
            d = int(parts[3])
            if a <= 0 or a == 127:
                return "invalid IP address"
            elif d == 0:
                return "host id  should not be 0 or less than zero "
            elif a >= 255:
                return "should not be 255 or greater than 255 or less than 0 A"
            elif b >= 255 or b < 0:
                return "should not be 255 or greater than 255 or less than 0 B"
            elif c >= 255 or c < 0:
                return "should not be 255 or greater than 255 or less than 0 C"
            elif d >= 255 or c < 0:
                return "should not be 255 or greater than 255 or less than 0 D"
            else:
                return "Valid IP address ", ip