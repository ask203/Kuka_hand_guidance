import numpy as np


###ip address --------------------------------------------------------------------------------------------------------------
ip_KUKACell = '192.168.1.15'  #ip of Kuka KR 4 (piano robot)
ip_sensor = '192.168.1.1'   #ip of F/T sensor.
port_KUKACell = 7000
#---------------------------------------------------------------------------------------------------------------------------



## relative distance in cms for robot movement------------------------------------------------------------------------------
KUKA_posX_rel = 0.0
KUKA_posY_rel = 0.0
KUKA_posZ_rel = 0.0
KUKA_posA_rel = 0.0
KUKA_posB_rel = 0.0
KUKA_posC_rel = 0.0

KUKA_reset_rel_move = np.array([KUKA_posX_rel, KUKA_posY_rel, KUKA_posZ_rel, KUKA_posA_rel,
                                   KUKA_posB_rel, KUKA_posC_rel], dtype="float")

#--------------------------------------------------------------------------------------------------------------------------


#changable parameters------------------------------------------------------------------------------------------------------
# specifies number of packet to be averaged while reading sensor value via UDP
packet_group = 10        

# robot moves after this force threshold is crossed (value in N)
force_threshold = 5    

# affects the step movement per force value. (impedance_factor * force = distance to be moved)
impedance_factor = 0.1     
#--------------------------------------------------------------------------------------------------------------------------
