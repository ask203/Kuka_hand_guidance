'''
Created by SEK0061@vsb.cz
'''
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import PhotoImage
import move_relative #comment this line for runnning without robot



def close_window():
    move_relative.stop_script()
    if messagebox.askyesno("Close", "Are you sure you want to close?\n\nNote: Press stop before closing*"):
        root.quit()


# Set up the UI
root = tk.Tk()
root.title("Robot Navigation System")
# root.attributes('-fullscreen', True)  # Set the window to full screen

# Load and display a logo in the corner of the UI
logo = PhotoImage(file="logo_2.png")  # Ensure "logo_2.png" exists in your project directory
logo_label = tk.Label(root, image=logo)
logo_label.pack(anchor='nw', pady=10, padx=10)

# Create a frame for buttons to use grid layout
buttons_frame = tk.Frame(root)
buttons_frame.pack(pady=20)
buttons_frame.configure(background='#00A499')
# Buttons using grid within the buttons frame

style = ttk.Style()
style.configure('TButton', font=('Helvetica', 20), padding=(20, 10))

#remove command for running without connection to robot
start_button = ttk.Button(buttons_frame, text="Start",command=move_relative.start_script,style='TButton') 
start_button.grid(row=0, column=0, padx=10, pady=20)

stop_button = ttk.Button(buttons_frame, text="Stop",command=move_relative.stop_script, style='TButton')
stop_button.grid(row=1, column=0, padx=10, pady=20)

close_button = ttk.Button(buttons_frame, text="Close", command=close_window,style='TButton')
close_button.grid(row=5, column=0, padx=10, pady=20)

# Configure background
root.configure(bg='#00A499')

# Ensure clean exit
root.protocol("WM_DELETE_WINDOW", close_window)

# Start the application
root.mainloop()
