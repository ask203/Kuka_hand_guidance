Guidance for Running the Force Torque Control Package:

This package combined  with KRL programming is used for enabling hand-guided navigation 
of the robot using the FT sensor.
It offers an alternative solution to the OEM KUKA.ForceTorqueControl package provided by KUKA. 
______________________________________________________________________________________________
Option 1: Connection with the Robot and Sensor
----------------------------------------------------------------------------------------------

Step 1: Configure Parameters:
*Open parameters.py and ensure correct parameters are set for connecting with the 
 robot and sensor.

Step 2: Run the UI Script:
*Execute the ui.py script.

Step 3: Start Hand Navigation:
*Upon running ui.py, a user interface (UI) window will appear.
*Click the "Start" button to initiate the hand navigation program.

Step 4: Stop the Program:
*To halt the program, press the "Stop" button.

Step 5: Close the UI:
*When finished, click the "Close" button to exit the entire UI.
______________________________________________________________________________________________
Option 2: Without Connection
----------------------------------------------------------------------------------------------

*The UI script (ui.py) can be executed independently from the robot connection.
*If you wish to run the UI without connecting to the robot, follow the instructions below:
*Comment out the relevant sections in the script as indicated by the provided comments.
*Run ui.py to explore the user interface without establishing a connection with the robot.